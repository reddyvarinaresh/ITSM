Anyone can contribute though they approved or not it depends
